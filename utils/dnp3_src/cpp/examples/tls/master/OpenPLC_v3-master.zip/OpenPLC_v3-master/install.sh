#!/bin/bash
./background_installer.sh $1 2>&1 | tee install_log.txt
